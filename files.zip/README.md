# AI-Powered Delivery Post Office Identification System

This project is designed to identify the nearest post office based on an address extracted from an uploaded image using OCR and geolocation services.

## Features
- Extract addresses from images using Tesseract OCR.
- Identify the nearest post office using Google Maps API.
- Provide a REST API for integration with delivery systems.

## Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/ai-powered-delivery-post-office.git
   cd ai-powered-delivery-post-office
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the application:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000
   ```

4. Access the API at `http://localhost:8000`.

## Docker
To run the application in a Docker container:
1. Build the Docker image:
   ```bash
   docker build -t ai-powered-delivery-post-office .
   ```

2. Run the Docker container:
   ```bash
   docker run -p 8000:8000 ai-powered-delivery-post-office
   ```

## API Endpoints
### POST `/identify-post-office/`
Upload an image file containing an address to identify the nearest post office.

Example Response:
```json
{
  "address": "123 Main Street, Cityville",
  "nearest_post_office": {
    "name": "Cityville Post Office",
    "address": "456 Elm Street, Cityville",
    "location": {
      "lat": 12.34,
      "lng": 56.78
    }
  }
}
```

## License
This project is licensed under the MIT License.