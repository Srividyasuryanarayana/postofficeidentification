from fastapi import FastAPI, UploadFile, HTTPException
from app.services.geolocation_service import find_nearest_post_office
from app.services.ocr_service import extract_address_from_image

app = FastAPI()

@app.post("/identify-post-office/")
async def identify_post_office(file: UploadFile):
    """
    Identify the nearest post office based on the address extracted from the uploaded image.
    """
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image.")

    # Extract address from the uploaded image
    address = extract_address_from_image(file.file)
    if not address:
        raise HTTPException(status_code=400, detail="Unable to extract address from the image.")

    # Find the nearest post office for the extracted address
    nearest_post_office = find_nearest_post_office(address)
    if not nearest_post_office:
        raise HTTPException(status_code=404, detail="No nearby post office found.")

    return {"address": address, "nearest_post_office": nearest_post_office}