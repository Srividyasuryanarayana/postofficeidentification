import requests

API_KEY = "your_google_maps_api_key"

def find_nearest_post_office(address: str) -> dict:
    """
    Finds the nearest post office to the given address using the Google Maps API.
    """
    try:
        # Geocode the address
        geocode_url = f"https://maps.googleapis.com/maps/api/geocode/json?address={address}&key={API_KEY}"
        geocode_response = requests.get(geocode_url).json()

        if not geocode_response.get("results"):
            return None

        location = geocode_response["results"][0]["geometry"]["location"]
        lat, lng = location["lat"], location["lng"]

        # Find nearby post offices
        places_url = (
            f"https://maps.googleapis.com/maps/api/place/nearbysearch/json?"
            f"location={lat},{lng}&radius=5000&type=post_office&key={API_KEY}"
        )
        places_response = requests.get(places_url).json()

        if not places_response.get("results"):
            return None

        nearest_post_office = places_response["results"][0]
        return {
            "name": nearest_post_office["name"],
            "address": nearest_post_office["vicinity"],
            "location": nearest_post_office["geometry"]["location"],
        }
    except Exception as e:
        print(f"Error during geolocation: {e}")
        return None