import pytesseract
from PIL import Image

def extract_address_from_image(image_file) -> str:
    """
    Extracts an address from an image file using OCR.
    """
    try:
        image = Image.open(image_file)
        text = pytesseract.image_to_string(image)
        # Apply logic to extract a structured address from the text
        address = parse_address_from_text(text)
        return address
    except Exception as e:
        print(f"Error during OCR: {e}")
        return None

def parse_address_from_text(text: str) -> str:
    """
    Parses a structured address from raw text using simple heuristics.
    """
    # Example: Extract lines with postal codes or city names
    address_lines = [line for line in text.split("\n") if "Street" in line or "City" in line]
    return " ".join(address_lines)